#' Computes the location-bandwidth grid for the multiscale test.
#' 
#' @param T          Sample size.
#' @param u.grid     Vector of location points in the unit interval [0,1].
#'                   If u.grid=NULL, a default grid is used.
#' @param h.grid     Vector of bandwidths, each bandwidth is supposed to lie in (0,0.5).
#'                   If h.grid=NULL, a default grid is used.
#' @param deletions  Vector of location-bandwidth points (u,h) that are deleted from the grid.
#'                   Default is deletions=NULL in which case nothing is deleted.
#' @return gset      Matrix of location-bandwidth points (u,h) that remains after deletions,
#'                   the i-th row gset[i,] corresponds to the i-th point (u,h).
#' @return bws       Vector of bandwidths (after deletions).
#' @return lens      Vector of length=length(bws), lens[i] gives the number of 
#'                   locations in the grid for the i-th bandwidth level.
#' @return gtype     Type of grid that is used, either 'default' or 'non-default'.
#' @return gset_full Matrix of all location-bandwidth pairs (u,h) including deleted ones.
#' @return pos_full  Vector indicating which points (u,h) have been deleted.
#' 
#' @export 
#' 
#' @examples
#' construct_grid(100)
#' construct_grid(100, u.grid = seq(from = 0.05, to = 1, by = 0.05), h.grid = c(0.1, 0.2, 0.3, 0.4))


construct_grid <- function(T, u.grid=NULL, h.grid=NULL, deletions=NULL){
  # 
  # Outputs: list with the elements
 

  grid.type <- "non-default"
  if (is.null(u.grid) & is.null(h.grid)){
    grid.type <- "default"
    #Tlen <- min(T,1000)
    Tlen <- T
    u.grid <- seq(from = 5/Tlen, to = 1, by = 5/Tlen)
    h.grid <- seq(from = 5/Tlen, to = 1/4, by = 5/Tlen)
    h.grid <- h.grid[h.grid > log(Tlen)/Tlen]
  }

  gset      <- expand.grid(u=u.grid, h=h.grid) 
  gset.full <- gset
  N         <- dim(gset)[1]
  pos.vec   <- 1:N

  if(!is.null(deletions))
    pos.vec <- deletions

  pos.full <- pos.vec
  pos.vec  <- pos.vec[!is.na(pos.vec)]
  gset     <- gset[pos.vec,] 

  bws <- unique(gset[,2])
  lengths.u <- rep(NA,length(bws))
  for(i in 1:length(bws))
     lengths.u[i] <- sum(gset[,2] == bws[i])
  
  return(list(gset=gset, bws=bws, lens=lengths.u, gtype=grid.type, gset_full=gset.full, pos_full=pos.full))
}