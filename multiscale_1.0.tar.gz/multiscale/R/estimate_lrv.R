#' Computes autocovariances at lags 0 to p for the ell-th differences of data.
#' 
#' @keywords internal
#' @param data       Time series for which we calculate autocovariances.
#' @param ell        Order of differences used.
#' @param p          Maximum lag for the autocovariances
#' @return autocovs  Vector of length (p + 1) that consists of empirical autocoavariances fr the corresponding lag - 1

emp_acf <- function(data, ell, p){
  y.diff   <- diff(data, ell)
  len      <- length(y.diff)
  autocovs <- rep(0, p + 1)
  for(k in 1:(p + 1)) {
    autocovs[k] <- sum(y.diff[k:len] * y.diff[1:(len - k + 1)])/len
  }
  return(autocovs)
}

#' Computes variance of AR(p) innovation terms eta.
#' 
#' @keywords internal
#' @param data      Time series.
#' @param coefs     Estimated coefficients.
#' @param p         AR order of the time series.
#' @return var.eta  Variance of the innovation term

variance_eta <- function(data, coefs, p){
  y.diff <- diff(data)
  len    <- length(y.diff)
  x.diff <- matrix(0, nrow = len - p, ncol = p)
  for(i in 1:p) {
     x.diff[, i] <- y.diff[(p + 1 - i):(len - i)]
  }
  y.diff  <- y.diff[(p + 1):len]      
  resid   <- y.diff - as.vector(x.diff %*% coefs)
  var.eta <- mean(resid^2) / 2
  return(var.eta)
}

#' Computes vector of correction terms for second-stage estimator 
#' of AR parameters as described in Khismatullina, Vogt (2019).
#' 
#' @keywords internal
#' @param coefs     Given (estimated) coefficients of the AR time series. Time series.
#' @param var.eta   Variance of the innovation term
#' @param len       Length of the vector of the corrections
#' @return c.vec    Vector of the corrections terms of length len.
corrections <- function(coefs, var.eta, len){
  p        <- length(coefs)  
  c.vec    <- rep(0,len)
  c.vec[1] <- 1
  for(j in 2:len){
    lags     <- (j - 1):max(j - p, 1)
    c.vec[j] <- sum(coefs[1:length(lags)] * c.vec[lags])  
  }
  c.vec <- c.vec * var.eta
  return(c.vec)
}

#' Computes estimator of the AR(p) coefficients by the procedure from Khismatullina and Vogt (2019).
#'
#' @keywords internal
#' @param data      Time series.
#' @param L1,L2     Tuning parameters.
#' @param correct   Vector of the corrections, either zero or calculated by the function corections().
#' @param p         AR order of the time series.
#' @return a.hat    Vector of length p  of estimated AR coefficients.
AR_coef <- function(data, L1, L2, correct, p){
  # computes estimator of the AR coefficients  
  pos <- 0
  a.mat <- matrix(0, nrow = L2 - L1 + 1, ncol = p)
  for(ell in L1:L2){
    pos <- pos + 1
    autocovs <- emp_acf(data, ell, p)
    cov.mat  <- matrix(0,ncol=p,nrow=p)
    for(i in 1:p){
      for(j in 1:p){
         cov.mat[i,j] <- autocovs[abs(i-j)+1]
      }
    }
    if(ell >= p) {
      correct.vec <- correct[(ell-1+1):(ell-p+1)]
    } else  {
      correct.vec <- c(correct[(ell-1+1):1],rep(0,p-ell))
    }
    cov.vec <- autocovs[2:(p+1)] + correct.vec
    a.mat[pos,] <- solve(cov.mat) %*% cov.vec 
  }    
  a.hat <- colMeans(a.mat)
  a.hat <- as.vector(a.hat)
  return(a.hat)
}

#' Computes estimator of the long-run variance of the error terms.
#' 
#' @description     A diffrenece based estimator for the coefficients and long-run variance
#'                  in case of a nonparametric regression model Y(t) = m(t/T) + e(t) where
#'                  the errors are AR(p). The procedure was first introduced in
#'                  Khismatullina and Vogt (2019).
#' 
#' @param data      A vector of Y(1), Y(2), ... Y(T).
#' @param q,r.bar   Integers, tuning parameters.
#' @param p         AR order of the error terms.
#' @return lrv      Estimator of the long run variance of the error terms.
#' @return ahat     Vector of length p of estimated AR coefficients.
#' @return vareta   Estimator of the variance of the innovation term
#' 
#' @export
estimate_lrv <- function(data, q, r.bar, p){
    a.tilde       <- AR_coef(data=data, L1=q, L2=q, correct=rep(0,max(p,q)+1), p=p)
    sig.eta.tilde <- variance_eta(data=data, coefs=a.tilde, p=p)
    correct       <- corrections(coefs=a.tilde, var.eta=sig.eta.tilde, len=r.bar+1)
    a.hat         <- AR_coef(data=data, L1=1, L2=r.bar, correct=correct, p=p)
    sig.eta.hat   <- variance_eta(data=data, coefs=a.hat, p=p)
    lrv.hat       <- sig.eta.hat/(1-sum(a.hat))^2 
    return(list(lrv=lrv.hat, ahat=a.hat, vareta=sig.eta.hat))
}