#' Plots SiZer map from the test results of the multiscale testing procedure.
#' 
#' @param u.grid       Vector of location points in the unit interval [0,1].
#' @param h.grid       Vector of bandwidths from (0,0.5).
#' @param test.results Matrix of test results created by multiscale_test(). 
#' @param plot.title   Title of the plot. Default is NA, so no title is written.
#' @param greyscale    Whether SiZer map is plotted in grey scale. Default is FALSE.
#' @param ...          Any further options to be passed to the image function
#' 
#' @export

plot_SiZer_map <- function(u.grid, h.grid, test.results, plot.title = NA, greyscale = FALSE, ...){
  
  if (greyscale){
    col.vec <- c("#F7F7F7", "#969696", "#525252", "#636363")
  } else {
    col.vec <- c("red", "purple", "blue", "gray") 
  }
  temp    <- sort(unique(as.vector(test.results))) + 2
  temp    <- seq(min(temp),max(temp),by=1)
  col.vec <- col.vec[temp]
  
  image(x=u.grid, y=log(h.grid,10), z=t(test.results), col=col.vec, xlab = '', ylab=expression(log[10](h)), main = plot.title, xaxt = 'n', mgp=c(1,0.5,0), ...)
}