#' Compute the set of minimal intervals as described in Duembgen (2002)
#'  
#' @description The result of our multiscale test is the set of all intervals  that have a corresponding
#'              test statistic bigger than the respective critical value. In order to make understandable
#'              statistic statements about these intervals, we need to find so-called
#'              miniml intervals: for a given set of intervals K, all intervals J such that K
#'              does not contain a proper subset of J are called minimal.
#'              Given K, this function computes the set of minimal intervals.
#'              Procedure is described in Duembgen (2002).
#' @export
#'
#' @param dataset    Set of all intervals  that have a corresponding test statistic bigger than the respective critical value         Sample size.
#' @return p_t_set   Set of minimal intervals

compute_minimal_intervals <- function(dataset){
  set_cardinality <- nrow(dataset) 
  if (set_cardinality > 1) {
    dataset <- dataset[order(dataset$startpoint, -dataset$endpoint),] #Ordering such that we don't need to check previous intervals
    rownames(dataset) <- 1:nrow(dataset) #restoring the indices after ordering
    dataset[['contains']] <- numeric(set_cardinality)
    for (i in 1:(set_cardinality-1)){
      for (j in (i+1):set_cardinality){
        if ((dataset$startpoint[i] <= dataset$startpoint[j]) & (dataset$endpoint[i] >= dataset$endpoint[j])) {
          dataset[['contains']][i] <- 1 #We are marking all the intervals that contain at least one another interval
          break
        }
      }
    }
    p_t_set <- subset(dataset, contains == 0, select = c(startpoint, endpoint, values))#Subsetting everything not marked
  } else {p_t_set <- dataset}
  return(p_t_set) 
}