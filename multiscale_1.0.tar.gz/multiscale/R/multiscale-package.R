#' multiscale-package: Multiscale Inference for Nonparametric Regression(s) with Time Series Errors
#'
#' This package performs a multiscale analysis of a nonparametric regression
#' or nonparametric regressions with time series errors.
#' 
#' @description This package performs a multiscale analysis of a nonparametric
#'   regression or nonparametric regressions with time series errors.
#'   
#'   In case of a single non-parametric regression, the multiscale method to
#'   test qualitative hypotheses about the nonparametric time trend \eqn{m} in the
#'   model \eqn{Y_t = m(t/T) + \eps_t} with time series errors \eqn{\eps_t} is provided.
#'   The method was first proposed in Khismatullina and Vogt (2019). It allows to test
#'   for shape properties (areas of monotonic decrease or increase) of the trend \eqn{m}.
#'   
#'   In case of multiple non-parametric regressions, the multiscale method
#'   to test qualitative hypotheses about the nonparametric time trends \eqn{m_i} in the model
#'   \eqn{Y_{i, t} = m_i(t/T) + \eps_{i, t}} with time series errors \eqn{\eps_{i, t}}
#'   is provided. The method was first proposed in Khismatullina and Vogt (??).
#'   It allows to test for comparison of the trend \eqn{m_i} and further
#'   to cluster the regressions based on the estiamted difference between the trends.
#'   
#'   Moreover, in order to perform these methods, an estimator of the long-run error
#'   variance \eqn{\sigma^2 = \sum_{l=-\infty}^{\infty} Cov(\eps_0, \eps_l)} is required.
#'   Hence, the package also provides the difference-based estimator for the case that
#'   the errors belong to the class of \eqn{AR(\infty)} processes. The estimator was
#'   first proposed in Khismatullina and Vogt (2019).
#'
#' @docType package
#' @name multiscale-package
#' @aliases multiscale
#' @seealso \url{https://rss.onlinelibrary.wiley.com/doi/full/10.1111/rssb.12347}
#' @references Khismatullina M., Vogt M. Multiscale inference and long-run variance
#'   estimation in non-parametric regression with time series errors
#'   //Journal of the Royal Statistical Society: Series B (Statistical Methodology). - 2019.
NULL