#' Calculates different information criterions for the number of time series 
#' based on the long-run variance estimator (defined in Khismatullina and Vogt (2019))
#' for a range of tuning parameters. 
#' 
#' @export
#' 
#' @description Tries to fit AR(1), ... AR(9) models for all the time series given
#'              and calculates different information criterions (FPE, AIC, AICC, SIC, HQ)
#'              for each of this fits. For 
#' @param data  One or a number of time series in a matrix. Column names of the matrix should be reasonable
#' @param q     A vector of integers that consisits of different tuning parameters to analyse.
#'              If not supplied, q is taken to be [2log(T)]:([2sqrt(T)] + 1).
#' @param r     A vector of integers that consisits of different tuning parameters r.bar to analyse.
#'              If not supplied, r = 5:15.
#'              
#' @return      A list with a number of elements.
#' orders       A vector of chosen orders of length equal to the number of time series.
#'              For each time series the order is calculated as max(which.min(FPE), ... which.min(HQ))
#' The rest of the elelments of the list are matrices that contain selected orders (among 1, ..., 9)
#' for each information criterion. One matrix for each time series               

select_order <- function(data, q = NULL, r = 5:15){

  Tlen <- nrow(data)
  N_ts <- ncol(data)

  if (is.null(q)){
    q = seq(floor(2 * log(Tlen)), ceiling(2 * sqrt(Tlen)), by = 1) 
  }
  
  result_list <- list()
  order_results <- c()
  if (N_ts == 1){
    list_names <- c('the only time series')
  } else {
    list_names <- colnames(data)
  }
    
  for (j in 1:N_ts){
    criterion_matrix <- expand.grid(q = q, r = r)
    
    criterion_matrix$FPE  <- numeric(length = nrow(criterion_matrix))
    criterion_matrix$AIC  <- numeric(length = nrow(criterion_matrix))
    criterion_matrix$AICC <- numeric(length = nrow(criterion_matrix))
    criterion_matrix$SIC  <- numeric(length = nrow(criterion_matrix))
    criterion_matrix$HQ   <- numeric(length = nrow(criterion_matrix))
    
    for (i in 1:nrow(criterion_matrix)){
      FPE <- c()
      AIC <- c()
      AICC <- c()
      SIC <- c()
      HQ <- c()
      
      different_orders <- (1:9)
      
      for (order in different_orders){
        AR.struc      <- estimate_lrv(data=data[, j], q=criterion_matrix$q[[i]], r.bar=criterion_matrix$r[[i]], p=order)
        sigma_eta_hat <- sqrt(AR.struc$vareta)
        FPE <- c(FPE, (sigma_eta_hat^2 * (Tlen + order)) / (Tlen - order))
        AIC <- c(AIC, Tlen * log(sigma_eta_hat^2) + 2 * order)
        AICC <- c(AICC, Tlen * log(sigma_eta_hat^2) + Tlen * (1 + order / Tlen)/(1 - (order +2)/Tlen))
        SIC <- c(SIC, log(sigma_eta_hat^2) + order * log(Tlen) / Tlen)
        HQ <- c(HQ, log(sigma_eta_hat^2) + 2 * order * log(log(Tlen)) / Tlen)
      }
      criterion_matrix$FPE[[i]]  <- which.min(FPE)
      criterion_matrix$AIC[[i]]  <- which.min(AIC)
      criterion_matrix$AICC[[i]] <- which.min(AICC)
      criterion_matrix$SIC[[i]]  <- which.min(SIC)
      criterion_matrix$HQ[[i]]   <- which.min(HQ)
    }
    maxim <- max(criterion_matrix[, 3:7])
    order_results <- c(order_results, maxim)
    cat("For ", list_names[j], " the results are as follows: ", max(criterion_matrix$FPE), " ", max(criterion_matrix$AIC), " ", max(criterion_matrix$AICC), " ", max(criterion_matrix$SIC), " ", max(criterion_matrix$HQ), " \n")
    result_list[[list_names[j]]] <- criterion_matrix
  }
  result_list[['orders']] <- order_results
  return(result_list)
}